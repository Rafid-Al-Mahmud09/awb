exports.getName = () =>{
    return "Anisul Islam";
}

const getAge = () => {
    return "25";
}

const cgpa = 3.92;

// exports.getName = getName;
// exports.getAge = getAge;
// exports.result = cgpa;

// module.exports = {
//     getName,
//     getAge,
//     cgpa
// }
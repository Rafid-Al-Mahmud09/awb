// const randomFruitsName = require("random-fruits-name");
// console.log(randomFruitsName());

var moviesNames = require("movies-names");
console.log(moviesNames.random());
